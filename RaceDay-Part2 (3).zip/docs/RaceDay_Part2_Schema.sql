/* =====================================================================
   RaceDay - SQL Server database script (matches the EF Core model in
   Part2/RaceDay.Api/Models and Data/RaceDayDbContext.cs)
   Author: Sade Mzila
   Run in SSMS against your SQL Server instance.

   NOTE: Use EITHER this script OR "dotnet ef database update" to create
   the database - not both. If you run this script, the API still works,
   but skip the EF migration step in the README.
   ===================================================================== */

IF DB_ID(N'RaceDayDb') IS NULL
    CREATE DATABASE RaceDayDb;
GO

USE RaceDayDb;
GO

/* ---------- Users ---------- */
CREATE TABLE dbo.Users
(
    Id           INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
    FirstName    NVARCHAR(100)  NOT NULL,
    LastName     NVARCHAR(100)  NOT NULL,
    Email        NVARCHAR(256)  NOT NULL,
    PasswordHash NVARCHAR(MAX)  NOT NULL,           -- hashed by the API, never plain text
    Role         NVARCHAR(20)   NOT NULL,
    PhoneNumber  NVARCHAR(30)   NULL,
    DateOfBirth  DATETIME2      NULL,
    CreatedAt    DATETIME2      NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Users_Role CHECK (Role IN (N'Organiser', N'Participant'))
);
CREATE UNIQUE INDEX IX_Users_Email ON dbo.Users (Email);
GO

/* ---------- Events ---------- */
CREATE TABLE dbo.Events
(
    Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Events PRIMARY KEY,
    Name        NVARCHAR(150)  NOT NULL,
    Description NVARCHAR(2000) NOT NULL,
    [Date]      DATETIME2      NOT NULL,
    Location    NVARCHAR(200)  NOT NULL,
    DistanceKm  DECIMAL(6,2)   NOT NULL,
    EventType   NVARCHAR(20)   NOT NULL,
    OrganiserId INT            NOT NULL,
    CONSTRAINT CK_Events_EventType CHECK (EventType IN (N'Run', N'Walk', N'Cycle')),
    CONSTRAINT FK_Events_Users_OrganiserId FOREIGN KEY (OrganiserId)
        REFERENCES dbo.Users (Id) ON DELETE NO ACTION
);
CREATE INDEX IX_Events_OrganiserId ON dbo.Events (OrganiserId);
GO

/* ---------- Categories ---------- */
CREATE TABLE dbo.Categories
(
    Id         INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Categories PRIMARY KEY,
    EventId    INT           NOT NULL,
    Name       NVARCHAR(100) NOT NULL,
    MinAge     INT           NULL,
    MaxAge     INT           NULL,
    DistanceKm DECIMAL(6,2)  NULL,
    CONSTRAINT FK_Categories_Events_EventId FOREIGN KEY (EventId)
        REFERENCES dbo.Events (Id) ON DELETE CASCADE
);
CREATE INDEX IX_Categories_EventId ON dbo.Categories (EventId);
GO

/* ---------- Enrolments ---------- */
CREATE TABLE dbo.Enrolments
(
    Id            INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Enrolments PRIMARY KEY,
    EventId       INT          NOT NULL,
    CategoryId    INT          NOT NULL,
    ParticipantId INT          NOT NULL,
    Status        NVARCHAR(20) NOT NULL,
    EnrolledAt    DATETIME2    NOT NULL CONSTRAINT DF_Enrolments_EnrolledAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Enrolments_Status CHECK (Status IN (N'Pending', N'Confirmed', N'Cancelled')),
    CONSTRAINT FK_Enrolments_Events_EventId FOREIGN KEY (EventId)
        REFERENCES dbo.Events (Id) ON DELETE CASCADE,
    CONSTRAINT FK_Enrolments_Categories_CategoryId FOREIGN KEY (CategoryId)
        REFERENCES dbo.Categories (Id) ON DELETE NO ACTION,
    CONSTRAINT FK_Enrolments_Users_ParticipantId FOREIGN KEY (ParticipantId)
        REFERENCES dbo.Users (Id) ON DELETE NO ACTION
);
CREATE UNIQUE INDEX IX_Enrolments_EventId_ParticipantId ON dbo.Enrolments (EventId, ParticipantId);
CREATE INDEX IX_Enrolments_CategoryId    ON dbo.Enrolments (CategoryId);
CREATE INDEX IX_Enrolments_ParticipantId ON dbo.Enrolments (ParticipantId);
GO

/* ---------- Results ---------- */
CREATE TABLE dbo.Results
(
    Id                INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Results PRIMARY KEY,
    EnrolmentId       INT       NOT NULL,
    FinishTime        TIME(7)   NOT NULL,
    FinishingPosition INT       NOT NULL,
    CapturedAt        DATETIME2 NOT NULL CONSTRAINT DF_Results_CapturedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Results_Enrolments_EnrolmentId FOREIGN KEY (EnrolmentId)
        REFERENCES dbo.Enrolments (Id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IX_Results_EnrolmentId ON dbo.Results (EnrolmentId);   -- one result per enrolment
GO

/* ---------- Optional demo data (events only) ----------
   Users must be created through the API (POST /api/auth/register) so their
   passwords are hashed correctly. Then replace @OrganiserId below with the
   Id of your Organiser account and run this block.

DECLARE @OrganiserId INT = 1;

INSERT INTO dbo.Events (Name, Description, [Date], Location, DistanceKm, EventType, OrganiserId)
VALUES
 (N'Durban Beachfront 10km', N'Flat, fast coastal run along the beachfront.', DATEADD(DAY, 30, SYSUTCDATETIME()), N'Durban Beachfront', 10, N'Run', @OrganiserId),
 (N'Umhlanga Park Walk',     N'Relaxed community walk for all ages.',        DATEADD(DAY, 45, SYSUTCDATETIME()), N'Umhlanga',          5,  N'Walk', @OrganiserId);

INSERT INTO dbo.Categories (EventId, Name, MinAge, MaxAge, DistanceKm)
SELECT Id, N'Under 20', 0, 19, NULL FROM dbo.Events WHERE Name = N'Durban Beachfront 10km'
UNION ALL
SELECT Id, N'Senior 20+', 20, 120, NULL FROM dbo.Events WHERE Name = N'Durban Beachfront 10km';
*/
