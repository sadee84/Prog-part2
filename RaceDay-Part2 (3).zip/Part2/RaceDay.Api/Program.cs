// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         Program.cs
// Purpose:      Application start-up: database, session, Swagger and middleware pipeline.
// Attribution:  Microsoft (n.d.) 'Session and state management in ASP.NET Core'; Microsoft (n.d.) 'Get started with Swashbuckle and ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.Reflection;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using RaceDay.Api.Data;
using RaceDay.Api.Models;

var builder = WebApplication.CreateBuilder(args);

// ---- Database: SQL Server via Entity Framework Core (code-first) ----
builder.Services.AddDbContext<RaceDayDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// ---- Password hashing (salted + hashed, original password is never stored) ----
builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();

// ---- Server-side session: keeps the logged-in user's id and role between requests ----
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.Name = ".RaceDay.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    options.IdleTimeout = TimeSpan.FromMinutes(30);
});

builder.Services.AddControllers()
    .AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

// ---- Swagger (OpenAPI) so every endpoint can be viewed and tested in the browser ----
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "RaceDay API",
        Version = "v1",
        Description = "REST API for the RaceDay event management system. " +
                      "Log in with POST /api/auth/login first - Swagger then reuses your session cookie."
    });

    // Pull the /// XML comments from the controllers into Swagger descriptions
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath)) c.IncludeXmlComments(xmlPath);
});

var app = builder.Build();

// Apply code-first migrations on start-up (skipped for the in-memory test database)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<RaceDayDbContext>();
    if (db.Database.IsRelational())
    {
        db.Database.Migrate();
    }
}

app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "RaceDay API v1"));

app.UseHttpsRedirection();
app.UseSession();          // must come before MapControllers
app.MapControllers();

app.Run();

// Makes Program visible to the test project (WebApplicationFactory<Program>)
public partial class Program { }
