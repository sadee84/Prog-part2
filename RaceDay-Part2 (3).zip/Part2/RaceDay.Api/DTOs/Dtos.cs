// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         Dtos.cs
// Purpose:      Request/response shapes and validation rules.
// Attribution:  Microsoft (n.d.) 'Model validation in ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.ComponentModel.DataAnnotations;
using RaceDay.Api.Models;

namespace RaceDay.Api.DTOs;

/// <summary>Generic error / info body, e.g. { "message": "..." }.</summary>
public record ApiMessage(string Message);

// ---------- Auth ----------
public class RegisterDto
{
    [Required, StringLength(100)] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(100)] public string LastName { get; set; } = string.Empty;
    [Required, EmailAddress, StringLength(256)] public string Email { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 8)] public string Password { get; set; } = string.Empty;

    /// <summary>Organiser or Participant.</summary>
    [EnumDataType(typeof(UserRole))] public UserRole Role { get; set; }

    /// <summary>Only needed for Organiser sign-up when an access code is configured.</summary>
    public string? OrganiserAccessCode { get; set; }
}

public class LoginDto
{
    [Required, EmailAddress] public string Email { get; set; } = string.Empty;
    [Required] public string Password { get; set; } = string.Empty;
}

public record UserDto(int Id, string FirstName, string LastName, string Email, UserRole Role);

public record SessionDto(int UserId, string FullName, string Email, UserRole Role, int IdleTimeoutMinutes);

// ---------- Profile ----------
public record UserProfileDto(int Id, string FirstName, string LastName, string Email, UserRole Role,
    string? PhoneNumber, DateTime? DateOfBirth);

public class UpdateProfileDto
{
    [Required, StringLength(100)] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(100)] public string LastName { get; set; } = string.Empty;
    [StringLength(30)] public string? PhoneNumber { get; set; }
    public DateTime? DateOfBirth { get; set; }
}

// ---------- Events ----------
public class EventUpsertDto
{
    [Required, StringLength(150)] public string Name { get; set; } = string.Empty;
    [Required, StringLength(2000)] public string Description { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    [Required, StringLength(200)] public string Location { get; set; } = string.Empty;
    [Range(0.1, 1000)] public decimal DistanceKm { get; set; }
    [EnumDataType(typeof(EventType))] public EventType EventType { get; set; }
}

public record EventDto(int Id, string Name, string Description, DateTime Date, string Location,
    decimal DistanceKm, EventType EventType, int OrganiserId, string OrganiserName,
    int CategoryCount, int EnrolmentCount);

// ---------- Categories ----------
public class CategoryUpsertDto
{
    [Required, StringLength(100)] public string Name { get; set; } = string.Empty;
    [Range(0, 120)] public int? MinAge { get; set; }
    [Range(0, 120)] public int? MaxAge { get; set; }
    [Range(0.1, 1000)] public decimal? DistanceKm { get; set; }
}

public record CategoryDto(int Id, int EventId, string Name, int? MinAge, int? MaxAge, decimal? DistanceKm);

// ---------- Enrolments ----------
public class EnrolRequestDto
{
    [Range(1, int.MaxValue)] public int CategoryId { get; set; }
}

public record EnrolmentDto(int Id, int EventId, string EventName, DateTime EventDate, int CategoryId,
    string CategoryName, int ParticipantId, string ParticipantName, string ParticipantEmail,
    EnrolmentStatus Status, DateTime EnrolledAt);

// ---------- Results ----------
public class CaptureResultDto
{
    /// <summary>Finish time as hh:mm:ss, e.g. "01:45:30".</summary>
    public TimeSpan FinishTime { get; set; }

    [Range(1, 100000)] public int FinishingPosition { get; set; }
}

public record ResultDto(int Id, int EnrolmentId, int EventId, string EventName, DateTime EventDate,
    string CategoryName, string ParticipantName, TimeSpan FinishTime, int FinishingPosition,
    int TotalFinishers);
