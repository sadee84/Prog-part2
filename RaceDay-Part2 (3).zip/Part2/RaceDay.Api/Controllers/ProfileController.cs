// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         ProfileController.cs
// Purpose:      View and update the logged-in user's profile.
// Attribution:  Microsoft (n.d.) 'Create web APIs with ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Filters;

namespace RaceDay.Api.Controllers;

[Route("api/profile")]
[SessionAuthorize] // both roles
public class ProfileController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    public ProfileController(RaceDayDbContext db) => _db = db;

    /// <summary>View my own profile.</summary>
    /// <response code="200">The logged-in user's profile.</response>
    /// <response code="401">Not logged in.</response>
    [HttpGet]
    [ProducesResponseType(typeof(UserProfileDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<UserProfileDto>> Get()
    {
        var u = await _db.Users.FindAsync(CurrentUserId);
        if (u is null) return Unauthorized(new ApiMessage("Your account no longer exists."));
        return Ok(new UserProfileDto(u.Id, u.FirstName, u.LastName, u.Email, u.Role, u.PhoneNumber, u.DateOfBirth));
    }

    /// <summary>Update my own profile (name, phone number, date of birth).</summary>
    /// <response code="200">Profile updated.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    [HttpPut]
    [ProducesResponseType(typeof(UserProfileDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<UserProfileDto>> Update(UpdateProfileDto dto)
    {
        var u = await _db.Users.FindAsync(CurrentUserId);
        if (u is null) return Unauthorized(new ApiMessage("Your account no longer exists."));

        u.FirstName = dto.FirstName.Trim();
        u.LastName = dto.LastName.Trim();
        u.PhoneNumber = dto.PhoneNumber?.Trim();
        u.DateOfBirth = dto.DateOfBirth;
        await _db.SaveChangesAsync();

        return Ok(new UserProfileDto(u.Id, u.FirstName, u.LastName, u.Email, u.Role, u.PhoneNumber, u.DateOfBirth));
    }
}
