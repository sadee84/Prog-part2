// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         ResultsController.cs
// Purpose:      Capturing and viewing finish times and positions.
// Attribution:  Microsoft (n.d.) 'EF Core - Querying data'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.Linq.Expressions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[SessionAuthorize] // any logged-in user; each action narrows to the correct role
public class ResultsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    public ResultsController(RaceDayDbContext db) => _db = db;

    // TotalFinishers = how many enrolments in the same event have a result (e.g. "47th out of 312")
    private static readonly Expression<Func<RaceResult, ResultDto>> ToDto = r => new ResultDto(
        r.Id, r.EnrolmentId, r.Enrolment.EventId, r.Enrolment.Event.Name, r.Enrolment.Event.Date,
        r.Enrolment.Category.Name,
        r.Enrolment.Participant.FirstName + " " + r.Enrolment.Participant.LastName,
        r.FinishTime, r.FinishingPosition,
        r.Enrolment.Event.Enrolments.Count(x => x.Result != null));

    /// <summary>Capture a participant's finish time and position after the event (Organiser only).</summary>
    /// <remarks>Expects: finishTime (hh:mm:ss) and finishingPosition. The event must already have taken place.</remarks>
    /// <response code="201">Result captured.</response>
    /// <response code="400">Invalid time/position, enrolment cancelled, or event has not happened yet.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Enrolment not found.</response>
    /// <response code="409">A result already exists, or the position is already taken in this event.</response>
    [HttpPost("api/enrolments/{enrolmentId:int}/result")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(ResultDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ResultDto>> Capture(int enrolmentId, CaptureResultDto dto)
    {
        var enrolment = await _db.Enrolments.Include(e => e.Event).FirstOrDefaultAsync(e => e.Id == enrolmentId);
        if (enrolment is null) return NotFound(new ApiMessage("Enrolment not found."));
        if (enrolment.Event.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only capture results for your own events.");
        if (enrolment.Status == EnrolmentStatus.Cancelled) return BadRequest(new ApiMessage("This enrolment was cancelled."));
        if (enrolment.Event.Date > DateTime.UtcNow) return BadRequest(new ApiMessage("Results can only be captured after the event has taken place."));
        if (dto.FinishTime <= TimeSpan.Zero) return BadRequest(new ApiMessage("finishTime must be greater than 00:00:00."));

        if (await _db.Results.AnyAsync(r => r.EnrolmentId == enrolmentId))
            return Conflict(new ApiMessage("A result already exists for this enrolment. Use PUT to change it."));
        if (await _db.Results.AnyAsync(r => r.Enrolment.EventId == enrolment.EventId && r.FinishingPosition == dto.FinishingPosition))
            return Conflict(new ApiMessage("That finishing position is already taken in this event."));

        var result = new RaceResult
        {
            EnrolmentId = enrolmentId, FinishTime = dto.FinishTime, FinishingPosition = dto.FinishingPosition
        };
        _db.Results.Add(result);
        await _db.SaveChangesAsync();

        var created = await _db.Results.Where(r => r.Id == result.Id).Select(ToDto).FirstAsync();
        return StatusCode(StatusCodes.Status201Created, created);
    }

    /// <summary>Correct a captured result (Organiser only).</summary>
    /// <response code="200">Result updated.</response>
    /// <response code="400">Invalid time or position.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Result not found.</response>
    /// <response code="409">That position is already taken in this event.</response>
    [HttpPut("api/results/{id:int}")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(ResultDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ResultDto>> Update(int id, CaptureResultDto dto)
    {
        var result = await _db.Results.Include(r => r.Enrolment).ThenInclude(e => e.Event)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (result is null) return NotFound(new ApiMessage("Result not found."));
        if (result.Enrolment.Event.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only edit results for your own events.");
        if (dto.FinishTime <= TimeSpan.Zero) return BadRequest(new ApiMessage("finishTime must be greater than 00:00:00."));

        var eventId = result.Enrolment.EventId;
        if (await _db.Results.AnyAsync(r => r.Id != id && r.Enrolment.EventId == eventId && r.FinishingPosition == dto.FinishingPosition))
            return Conflict(new ApiMessage("That finishing position is already taken in this event."));

        result.FinishTime = dto.FinishTime;
        result.FinishingPosition = dto.FinishingPosition;
        await _db.SaveChangesAsync();

        return Ok(await _db.Results.Where(r => r.Id == id).Select(ToDto).FirstAsync());
    }

    /// <summary>View all results for one of my events, ordered by finishing position (Organiser only).</summary>
    /// <response code="200">Results for the event.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("api/events/{eventId:int}/results")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(IEnumerable<ResultDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<ResultDto>>> GetForEvent(int eventId)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == eventId);
        if (ev is null) return NotFound(new ApiMessage("Event not found."));
        if (ev.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only view results for your own events.");

        return Ok(await _db.Results.Where(r => r.Enrolment.EventId == eventId)
            .OrderBy(r => r.FinishingPosition).Select(ToDto).ToListAsync());
    }

    /// <summary>View my own race results across all completed events (Participant only).</summary>
    /// <response code="200">My results, most recent event first.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Organisers cannot use this endpoint.</response>
    [HttpGet("api/results/mine")]
    [SessionAuthorize(UserRole.Participant)]
    [ProducesResponseType(typeof(IEnumerable<ResultDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IEnumerable<ResultDto>>> GetMine()
    {
        var me = CurrentUserId;
        return Ok(await _db.Results.Where(r => r.Enrolment.ParticipantId == me)
            .OrderByDescending(r => r.Enrolment.Event.Date).Select(ToDto).ToListAsync());
    }
}
