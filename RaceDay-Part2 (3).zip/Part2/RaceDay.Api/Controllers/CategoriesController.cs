// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         CategoriesController.cs
// Purpose:      Event categories (age/distance) CRUD.
// Attribution:  Microsoft (n.d.) 'Create web APIs with ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[SessionAuthorize] // any logged-in user; write actions narrow this to Organiser
public class CategoriesController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    public CategoriesController(RaceDayDbContext db) => _db = db;

    private static CategoryDto ToDto(Category c) => new(c.Id, c.EventId, c.Name, c.MinAge, c.MaxAge, c.DistanceKm);

    private static string? Validate(CategoryUpsertDto d)
    {
        if (d.MinAge is null && d.MaxAge is null && d.DistanceKm is null)
            return "Provide an age range (minAge/maxAge) or a distanceKm for the category.";
        if (d.MinAge is not null && d.MaxAge is not null && d.MinAge > d.MaxAge)
            return "minAge cannot be greater than maxAge.";
        return null;
    }

    /// <summary>List the categories of an event (both roles).</summary>
    /// <response code="200">Categories for the event.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("api/events/{eventId:int}/categories")]
    [ProducesResponseType(typeof(IEnumerable<CategoryDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<CategoryDto>>> GetForEvent(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.Id == eventId))
            return NotFound(new ApiMessage("Event not found."));

        var list = await _db.Categories.Where(c => c.EventId == eventId).OrderBy(c => c.Name).ToListAsync();
        return Ok(list.Select(ToDto));
    }

    /// <summary>Add an age or distance category to one of my events (Organiser only).</summary>
    /// <remarks>Expects: name, and an age range (minAge/maxAge) and/or distanceKm.</remarks>
    /// <response code="201">Category created.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Event not found.</response>
    [HttpPost("api/events/{eventId:int}/categories")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(CategoryDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<CategoryDto>> Create(int eventId, CategoryUpsertDto dto)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == eventId);
        if (ev is null) return NotFound(new ApiMessage("Event not found."));
        if (ev.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only add categories to your own events.");

        var problem = Validate(dto);
        if (problem is not null) return BadRequest(new ApiMessage(problem));

        var cat = new Category
        {
            EventId = eventId, Name = dto.Name.Trim(),
            MinAge = dto.MinAge, MaxAge = dto.MaxAge, DistanceKm = dto.DistanceKm
        };
        _db.Categories.Add(cat);
        await _db.SaveChangesAsync();
        return StatusCode(StatusCodes.Status201Created, ToDto(cat));
    }

    /// <summary>Update a category on one of my events (Organiser only).</summary>
    /// <response code="200">Category updated.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Category not found.</response>
    [HttpPut("api/categories/{id:int}")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(CategoryDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<CategoryDto>> Update(int id, CategoryUpsertDto dto)
    {
        var cat = await _db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.Id == id);
        if (cat is null) return NotFound(new ApiMessage("Category not found."));
        if (cat.Event.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only edit categories on your own events.");

        var problem = Validate(dto);
        if (problem is not null) return BadRequest(new ApiMessage(problem));

        cat.Name = dto.Name.Trim();
        cat.MinAge = dto.MinAge;
        cat.MaxAge = dto.MaxAge;
        cat.DistanceKm = dto.DistanceKm;
        await _db.SaveChangesAsync();
        return Ok(ToDto(cat));
    }

    /// <summary>Delete a category on one of my events (Organiser only). Not allowed if people enrolled in it.</summary>
    /// <response code="204">Category deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Category not found.</response>
    /// <response code="409">Category already has enrolments.</response>
    [HttpDelete("api/categories/{id:int}")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var cat = await _db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.Id == id);
        if (cat is null) return NotFound(new ApiMessage("Category not found."));
        if (cat.Event.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only delete categories on your own events.");
        if (await _db.Enrolments.AnyAsync(e => e.CategoryId == id))
            return Conflict(new ApiMessage("This category already has enrolments and cannot be deleted."));

        _db.Categories.Remove(cat);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
