// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         AuthController.cs
// Purpose:      Register, login, session info and logout endpoints.
// Attribution:  Microsoft (n.d.) 'PasswordHasher<TUser> class' (password hashing); Microsoft (n.d.) 'Session and state management in ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api/auth")]
public class AuthController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IPasswordHasher<User> _hasher;
    private readonly IConfiguration _config;

    public AuthController(RaceDayDbContext db, IPasswordHasher<User> hasher, IConfiguration config)
    {
        _db = db;
        _hasher = hasher;
        _config = config;
    }

    /// <summary>Register a new account as an Organiser or a Participant.</summary>
    /// <remarks>
    /// Expects: firstName, lastName, email, password (min 8 chars), role (Organiser | Participant).
    /// If an Organiser access code is configured on the server, Organisers must also send it.
    /// </remarks>
    /// <response code="201">Account created. Returns the new user (no password).</response>
    /// <response code="400">Validation failed (missing fields, bad email, short password, invalid role).</response>
    /// <response code="403">Organiser access code missing or wrong.</response>
    /// <response code="409">An account with that email already exists.</response>
    [HttpPost("register")]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<UserDto>> Register(RegisterDto dto)
    {
        var email = dto.Email.Trim().ToLowerInvariant();

        if (await _db.Users.AnyAsync(u => u.Email == email))
            return Conflict(new ApiMessage("An account with that email already exists."));

        // Organiser accounts can be protected with a secret code (blank = open registration)
        if (dto.Role == UserRole.Organiser)
        {
            var requiredCode = _config["Registration:OrganiserAccessCode"];
            if (!string.IsNullOrWhiteSpace(requiredCode) && dto.OrganiserAccessCode != requiredCode)
                return ForbiddenMessage("A valid Organiser access code is required.");
        }

        var user = new User
        {
            FirstName = dto.FirstName.Trim(),
            LastName = dto.LastName.Trim(),
            Email = email,
            Role = dto.Role
        };
        user.PasswordHash = _hasher.HashPassword(user, dto.Password);

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created,
            new UserDto(user.Id, user.FirstName, user.LastName, user.Email, user.Role));
    }

    /// <summary>Log in with email and password. Starts a server-side session.</summary>
    /// <remarks>On success the session stores the user id and role, and a session cookie is returned.</remarks>
    /// <response code="200">Logged in. Returns session metadata and role.</response>
    /// <response code="400">Validation failed (missing email or password).</response>
    /// <response code="401">Invalid email or password.</response>
    [HttpPost("login")]
    [ProducesResponseType(typeof(SessionDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<SessionDto>> Login(LoginDto dto)
    {
        var email = dto.Email.Trim().ToLowerInvariant();
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == email);

        // Same message for "no such user" and "wrong password" so attackers learn nothing
        if (user is null ||
            _hasher.VerifyHashedPassword(user, user.PasswordHash, dto.Password) == PasswordVerificationResult.Failed)
        {
            return Unauthorized(new ApiMessage("Invalid email or password."));
        }

        HttpContext.Session.Clear();
        HttpContext.Session.SetInt32(SessionKeys.UserId, user.Id);
        HttpContext.Session.SetInt32(SessionKeys.UserRole, (int)user.Role);
        await HttpContext.Session.CommitAsync();

        return Ok(ToSessionDto(user));
    }

    /// <summary>Get the current session's user details and role.</summary>
    /// <response code="200">User session metadata and role.</response>
    /// <response code="401">Not logged in (or session expired).</response>
    [HttpGet("session")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(SessionDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<SessionDto>> GetSession()
    {
        var user = await _db.Users.FindAsync(CurrentUserId);
        if (user is null)
        {
            HttpContext.Session.Clear();
            return Unauthorized(new ApiMessage("Your account no longer exists."));
        }
        return Ok(ToSessionDto(user));
    }

    /// <summary>Log out and clear the session.</summary>
    /// <response code="200">Logged out.</response>
    /// <response code="401">Not logged in.</response>
    [HttpPost("logout")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return Ok(new ApiMessage("Logged out."));
    }

    private static SessionDto ToSessionDto(User u) =>
        new(u.Id, $"{u.FirstName} {u.LastName}", u.Email, u.Role, 30);
}
