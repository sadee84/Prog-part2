// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         ApiControllerBase.cs
// Purpose:      Base controller exposing the current user id/role from session.
// Attribution:  Microsoft (n.d.) 'Create web APIs with ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.DTOs;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

/// <summary>Shared helpers: who is logged in (read from session) and a 403 helper.</summary>
[ApiController]
[Produces("application/json")]
public abstract class ApiControllerBase : ControllerBase
{
    protected int CurrentUserId => HttpContext.Session.GetInt32(SessionKeys.UserId) ?? 0;

    protected UserRole CurrentRole => (UserRole)(HttpContext.Session.GetInt32(SessionKeys.UserRole) ?? 0);

    protected ObjectResult ForbiddenMessage(string message) =>
        StatusCode(StatusCodes.Status403Forbidden, new ApiMessage(message));
}
