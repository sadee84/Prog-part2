// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         EventsController.cs
// Purpose:      Event CRUD with role and ownership checks.
// Attribution:  Microsoft (n.d.) 'Create web APIs with ASP.NET Core'; Microsoft (n.d.) 'EF Core - Querying data'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.Linq.Expressions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api/events")]
[SessionAuthorize] // any logged-in user; write actions narrow this to Organiser
public class EventsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    public EventsController(RaceDayDbContext db) => _db = db;

    // Entity -> DTO projection, translated to SQL by EF Core
    private static readonly Expression<Func<Event, EventDto>> ToDto = e => new EventDto(
        e.Id, e.Name, e.Description, e.Date, e.Location, e.DistanceKm, e.EventType,
        e.OrganiserId, e.Organiser.FirstName + " " + e.Organiser.LastName,
        e.Categories.Count(),
        e.Enrolments.Count(x => x.Status != EnrolmentStatus.Cancelled));

    /// <summary>List events (both roles). Optional filters: type, upcomingOnly, search.</summary>
    /// <response code="200">List of events ordered by date.</response>
    /// <response code="401">Not logged in.</response>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<EventDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<IEnumerable<EventDto>>> GetAll(
        [FromQuery] EventType? type, [FromQuery] bool upcomingOnly = false, [FromQuery] string? search = null)
    {
        var now = DateTime.UtcNow;
        var query = _db.Events.AsQueryable();

        if (type.HasValue) query = query.Where(e => e.EventType == type.Value);
        if (upcomingOnly) query = query.Where(e => e.Date >= now);
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(e => e.Name.Contains(search) || e.Location.Contains(search));

        return Ok(await query.OrderBy(e => e.Date).Select(ToDto).ToListAsync());
    }

    /// <summary>List the events I created, including enrolment counts (Organiser dashboard).</summary>
    /// <response code="200">My events.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Participants cannot use this endpoint.</response>
    [HttpGet("mine")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(IEnumerable<EventDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IEnumerable<EventDto>>> GetMine()
    {
        var myId = CurrentUserId;
        return Ok(await _db.Events.Where(e => e.OrganiserId == myId)
            .OrderBy(e => e.Date).Select(ToDto).ToListAsync());
    }

    /// <summary>Get one event by id (both roles).</summary>
    /// <response code="200">The event.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventDto>> GetById(int id)
    {
        var dto = await _db.Events.Where(e => e.Id == id).Select(ToDto).FirstOrDefaultAsync();
        return dto is null ? NotFound(new ApiMessage("Event not found.")) : Ok(dto);
    }

    /// <summary>Create an event (Organiser only).</summary>
    /// <remarks>Expects: name, description, date, location, distanceKm, eventType (Run | Walk | Cycle).</remarks>
    /// <response code="201">Event created.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Participants cannot create events.</response>
    [HttpPost]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<EventDto>> Create(EventUpsertDto dto)
    {
        var ev = new Event
        {
            Name = dto.Name.Trim(),
            Description = dto.Description.Trim(),
            Date = dto.Date,
            Location = dto.Location.Trim(),
            DistanceKm = dto.DistanceKm,
            EventType = dto.EventType,
            OrganiserId = CurrentUserId
        };
        _db.Events.Add(ev);
        await _db.SaveChangesAsync();

        var created = await _db.Events.Where(e => e.Id == ev.Id).Select(ToDto).FirstAsync();
        return CreatedAtAction(nameof(GetById), new { id = ev.Id }, created);
    }

    /// <summary>Update an event I created (Organiser only).</summary>
    /// <response code="200">Event updated.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event not found.</response>
    [HttpPut("{id:int}")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventDto>> Update(int id, EventUpsertDto dto)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == id);
        if (ev is null) return NotFound(new ApiMessage("Event not found."));
        if (ev.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only modify events you created.");

        ev.Name = dto.Name.Trim();
        ev.Description = dto.Description.Trim();
        ev.Date = dto.Date;
        ev.Location = dto.Location.Trim();
        ev.DistanceKm = dto.DistanceKm;
        ev.EventType = dto.EventType;
        await _db.SaveChangesAsync();

        return Ok(await _db.Events.Where(e => e.Id == id).Select(ToDto).FirstAsync());
    }

    /// <summary>Delete an event I created (Organiser only). Also removes its categories and enrolments.</summary>
    /// <response code="204">Event deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or the event belongs to another Organiser.</response>
    /// <response code="404">Event not found.</response>
    [HttpDelete("{id:int}")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == id);
        if (ev is null) return NotFound(new ApiMessage("Event not found."));
        if (ev.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only delete events you created.");

        // Load children so deletion also works on providers without DB-level cascades
        var enrolments = await _db.Enrolments.Include(x => x.Result).Where(x => x.EventId == id).ToListAsync();
        _db.RemoveRange(enrolments.Where(x => x.Result != null).Select(x => x.Result!));
        _db.RemoveRange(enrolments);
        _db.RemoveRange(await _db.Categories.Where(c => c.EventId == id).ToListAsync());
        _db.Events.Remove(ev);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
