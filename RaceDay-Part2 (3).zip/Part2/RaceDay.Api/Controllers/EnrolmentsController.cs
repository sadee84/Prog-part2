// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         EnrolmentsController.cs
// Purpose:      Participants enrolling in events; organisers viewing enrolments.
// Attribution:  Microsoft (n.d.) 'EF Core - Querying data'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.Linq.Expressions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Filters;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[SessionAuthorize] // any logged-in user; each action narrows to the correct role
public class EnrolmentsController : ApiControllerBase
{
    private readonly RaceDayDbContext _db;
    public EnrolmentsController(RaceDayDbContext db) => _db = db;

    private static readonly Expression<Func<Enrolment, EnrolmentDto>> ToDto = e => new EnrolmentDto(
        e.Id, e.EventId, e.Event.Name, e.Event.Date, e.CategoryId, e.Category.Name,
        e.ParticipantId, e.Participant.FirstName + " " + e.Participant.LastName,
        e.Participant.Email, e.Status, e.EnrolledAt);

    /// <summary>Enter an event by choosing one of its categories (Participant only).</summary>
    /// <remarks>Expects: categoryId. The link between participant, event and category is saved immediately.</remarks>
    /// <response code="201">Enrolled (status Confirmed).</response>
    /// <response code="400">Category does not belong to the event, or the event has already taken place.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Organisers cannot enrol in events.</response>
    /// <response code="404">Event not found.</response>
    /// <response code="409">You are already enrolled in this event.</response>
    [HttpPost("api/events/{eventId:int}/enrolments")]
    [SessionAuthorize(UserRole.Participant)]
    [ProducesResponseType(typeof(EnrolmentDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<EnrolmentDto>> Enrol(int eventId, EnrolRequestDto dto)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == eventId);
        if (ev is null) return NotFound(new ApiMessage("Event not found."));
        if (ev.Date <= DateTime.UtcNow) return BadRequest(new ApiMessage("This event has already taken place."));

        var category = await _db.Categories.FirstOrDefaultAsync(c => c.Id == dto.CategoryId && c.EventId == eventId);
        if (category is null) return BadRequest(new ApiMessage("That category does not belong to this event."));

        var me = CurrentUserId;
        var existing = await _db.Enrolments.FirstOrDefaultAsync(e => e.EventId == eventId && e.ParticipantId == me);

        Enrolment enrolment;
        if (existing is null)
        {
            enrolment = new Enrolment
            {
                EventId = eventId, CategoryId = category.Id, ParticipantId = me,
                Status = EnrolmentStatus.Confirmed, EnrolledAt = DateTime.UtcNow
            };
            _db.Enrolments.Add(enrolment);
        }
        else if (existing.Status == EnrolmentStatus.Cancelled)
        {
            // Re-enrolling after cancelling re-uses the same row (one enrolment per person per event)
            existing.CategoryId = category.Id;
            existing.Status = EnrolmentStatus.Confirmed;
            existing.EnrolledAt = DateTime.UtcNow;
            enrolment = existing;
        }
        else
        {
            return Conflict(new ApiMessage("You are already enrolled in this event."));
        }

        await _db.SaveChangesAsync();
        var created = await _db.Enrolments.Where(e => e.Id == enrolment.Id).Select(ToDto).FirstAsync();
        return StatusCode(StatusCodes.Status201Created, created);
    }

    /// <summary>View all my enrolments with their status (Participant only).</summary>
    /// <response code="200">My enrolments, newest event first.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Organisers cannot use this endpoint.</response>
    [HttpGet("api/enrolments/mine")]
    [SessionAuthorize(UserRole.Participant)]
    [ProducesResponseType(typeof(IEnumerable<EnrolmentDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IEnumerable<EnrolmentDto>>> GetMine()
    {
        var me = CurrentUserId;
        return Ok(await _db.Enrolments.Where(e => e.ParticipantId == me)
            .OrderByDescending(e => e.Event.Date).Select(ToDto).ToListAsync());
    }

    /// <summary>View everyone enrolled in one of my events (Organiser only).</summary>
    /// <response code="200">Enrolments for the event.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or not the owner of the event.</response>
    /// <response code="404">Event not found.</response>
    [HttpGet("api/events/{eventId:int}/enrolments")]
    [SessionAuthorize(UserRole.Organiser)]
    [ProducesResponseType(typeof(IEnumerable<EnrolmentDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<EnrolmentDto>>> GetForEvent(int eventId)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == eventId);
        if (ev is null) return NotFound(new ApiMessage("Event not found."));
        if (ev.OrganiserId != CurrentUserId) return ForbiddenMessage("You can only view enrolments for your own events.");

        return Ok(await _db.Enrolments.Where(e => e.EventId == eventId)
            .OrderBy(e => e.Participant.LastName).Select(ToDto).ToListAsync());
    }

    /// <summary>Cancel my enrolment (Participant only). The record is kept with status Cancelled.</summary>
    /// <response code="204">Enrolment cancelled.</response>
    /// <response code="400">The event has already taken place.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not a Participant, or the enrolment belongs to someone else.</response>
    /// <response code="404">Enrolment not found.</response>
    [HttpDelete("api/enrolments/{id:int}")]
    [SessionAuthorize(UserRole.Participant)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Cancel(int id)
    {
        var enrolment = await _db.Enrolments.Include(e => e.Event).FirstOrDefaultAsync(e => e.Id == id);
        if (enrolment is null) return NotFound(new ApiMessage("Enrolment not found."));
        if (enrolment.ParticipantId != CurrentUserId) return ForbiddenMessage("You can only cancel your own enrolments.");
        if (enrolment.Event.Date <= DateTime.UtcNow) return BadRequest(new ApiMessage("This event has already taken place."));

        enrolment.Status = EnrolmentStatus.Cancelled;
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
