// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         SessionAuthorizeAttribute.cs
// Purpose:      Session-based authentication (401) and role check (403) filter.
// Attribution:  Microsoft (n.d.) 'Filters in ASP.NET Core' (authorization filters).
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Filters;

/// <summary>Keys used to store the logged-in user's details in server-side session.</summary>
public static class SessionKeys
{
    public const string UserId = "UserId";
    public const string UserRole = "UserRole";
}

/// <summary>
/// Blocks a request unless the session holds a logged-in user (401), and - when roles are
/// listed - unless that user has one of them (403). Put it on a controller for "any logged-in
/// user" and on an action to narrow it to one role.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class SessionAuthorizeAttribute : Attribute, IAuthorizationFilter
{
    private readonly UserRole[] _roles;

    public SessionAuthorizeAttribute(params UserRole[] roles) => _roles = roles;

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var session = context.HttpContext.Session;
        var userId = session.GetInt32(SessionKeys.UserId);
        var role = session.GetInt32(SessionKeys.UserRole);

        if (userId is null || role is null)
        {
            context.Result = new UnauthorizedObjectResult(
                new ApiMessage("You must be logged in to access this resource."));
            return;
        }

        if (_roles.Length > 0 && !_roles.Contains((UserRole)role.Value))
        {
            context.Result = new ObjectResult(
                new ApiMessage("Your role does not have access to this resource."))
            { StatusCode = StatusCodes.Status403Forbidden };
        }
    }
}
