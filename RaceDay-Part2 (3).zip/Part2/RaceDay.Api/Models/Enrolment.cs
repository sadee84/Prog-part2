// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         Enrolment.cs
// Purpose:      Entity/model class used by EF Core (code-first).
// Attribution:  Microsoft (n.d.) 'Entity Framework Core - Creating a model'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
namespace RaceDay.Api.Models;

/// <summary>Links a Participant, an Event and the chosen Category.</summary>
public class Enrolment
{
    public int Id { get; set; }

    public int EventId { get; set; }
    public Event Event { get; set; } = null!;

    public int CategoryId { get; set; }
    public Category Category { get; set; } = null!;

    public int ParticipantId { get; set; }
    public User Participant { get; set; } = null!;

    public EnrolmentStatus Status { get; set; } = EnrolmentStatus.Confirmed;
    public DateTime EnrolledAt { get; set; } = DateTime.UtcNow;

    public RaceResult? Result { get; set; }
}

/// <summary>Finish time and position captured by the Organiser after the event.</summary>
public class RaceResult
{
    public int Id { get; set; }
    public int EnrolmentId { get; set; }
    public Enrolment Enrolment { get; set; } = null!;

    public TimeSpan FinishTime { get; set; }
    public int FinishingPosition { get; set; }
    public DateTime CapturedAt { get; set; } = DateTime.UtcNow;
}
