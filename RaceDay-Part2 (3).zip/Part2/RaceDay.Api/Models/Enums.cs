// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         Enums.cs
// Purpose:      Entity/model class used by EF Core (code-first).
// Attribution:  Microsoft (n.d.) 'Entity Framework Core - Creating a model'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
namespace RaceDay.Api.Models;

/// <summary>The two roles the system supports.</summary>
public enum UserRole { Organiser = 1, Participant = 2 }

/// <summary>Type of event: run, walk or cycle.</summary>
public enum EventType { Run = 1, Walk = 2, Cycle = 3 }

/// <summary>Lifecycle of an enrolment (Part 3 colour-codes these).</summary>
public enum EnrolmentStatus { Pending = 1, Confirmed = 2, Cancelled = 3 }
