// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         User.cs
// Purpose:      Entity/model class used by EF Core (code-first).
// Attribution:  Microsoft (n.d.) 'Entity Framework Core - Creating a model'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Models;

public class User
{
    public int Id { get; set; }

    [Required, MaxLength(100)] public string FirstName { get; set; } = string.Empty;
    [Required, MaxLength(100)] public string LastName { get; set; } = string.Empty;
    [Required, MaxLength(256)] public string Email { get; set; } = string.Empty;

    // Only the HASH is stored - never the original password.
    [Required] public string PasswordHash { get; set; } = string.Empty;

    public UserRole Role { get; set; }
    [MaxLength(30)] public string? PhoneNumber { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<Event> OrganisedEvents { get; set; } = new List<Event>();
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}
