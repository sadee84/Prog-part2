// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         TestHelpers.cs
// Purpose:      Helpers to register/login users and create events in tests.
// Attribution:  Microsoft (n.d.) 'Integration tests in ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.Tests;

public static class TestHelpers
{
    public const string Password = "Password123!";

    public static string UniqueEmail() => $"user{Guid.NewGuid():N}@test.com";

    /// <summary>Registers a new user and logs them in. Each client keeps its own session cookie.</summary>
    public static async Task<(HttpClient Client, string Email, int UserId)> RegisterAndLoginAsync(
        RaceDayApiFactory factory, string role)
    {
        var client = factory.CreateClient();
        var email = UniqueEmail();

        var reg = await client.PostAsJsonAsync("/api/auth/register",
            new { firstName = "Test", lastName = role, email, password = Password, role });
        reg.EnsureSuccessStatusCode();

        var login = await client.PostAsJsonAsync("/api/auth/login", new { email, password = Password });
        login.EnsureSuccessStatusCode();

        var body = await login.Content.ReadFromJsonAsync<JsonElement>();
        return (client, email, body.GetProperty("userId").GetInt32());
    }

    public static object EventBody(DateTime date, string name = "Test Fun Run") => new
    {
        name,
        description = "A test event",
        date,
        location = "Durban",
        distanceKm = 10,
        eventType = "Run"
    };

    public static async Task<int> CreateEventAsync(HttpClient organiser, DateTime? date = null)
    {
        var res = await organiser.PostAsJsonAsync("/api/events",
            EventBody(date ?? DateTime.UtcNow.AddDays(30)));
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetInt32();
    }

    public static async Task<int> CreateCategoryAsync(HttpClient organiser, int eventId)
    {
        var res = await organiser.PostAsJsonAsync($"/api/events/{eventId}/categories",
            new { name = "10km Open", distanceKm = 10 });
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetInt32();
    }

    public static async Task<int> EnrolAsync(HttpClient participant, int eventId, int categoryId)
    {
        var res = await participant.PostAsJsonAsync($"/api/events/{eventId}/enrolments", new { categoryId });
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("id").GetInt32();
    }
}
