// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         RaceDayApiFactory.cs
// Purpose:      Test host that swaps SQL Server for an in-memory database.
// Attribution:  Microsoft (n.d.) 'Integration tests in ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using RaceDay.Api.Data;

namespace RaceDay.Tests;

/// <summary>
/// Starts the real API in memory for tests, but swaps SQL Server for an in-memory database
/// so tests (and GitHub Actions) need no SQL Server installed.
/// </summary>
public class RaceDayApiFactory : WebApplicationFactory<Program>
{
    private readonly string _dbName = "RaceDayTests-" + Guid.NewGuid();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureServices(services =>
        {
            // Remove the SQL Server registration made in Program.cs
            services.RemoveAll(typeof(DbContextOptions<RaceDayDbContext>));
            var leftovers = services
                .Where(d => d.ServiceType.FullName != null
                            && d.ServiceType.FullName.Contains("IDbContextOptionsConfiguration")
                            && d.ServiceType.FullName.Contains(nameof(RaceDayDbContext)))
                .ToList();
            foreach (var d in leftovers) services.Remove(d);

            services.AddDbContext<RaceDayDbContext>(o => o.UseInMemoryDatabase(_dbName));
        });
    }
}
