// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         EventTests.cs
// Purpose:      Tests: organiser event management and role rejection.
// Attribution:  xUnit.net (n.d.) 'Getting started with xUnit.net'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.Net;
using System.Net.Http.Json;

namespace RaceDay.Tests;

/// <summary>Organisers managing events, plus role rejection (Participant / other Organiser).</summary>
public class EventTests : IClassFixture<RaceDayApiFactory>
{
    private readonly RaceDayApiFactory _factory;
    public EventTests(RaceDayApiFactory factory) => _factory = factory;

    [Fact]
    public async Task Organiser_CanCreateUpdateAndDeleteOwnEvent()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");

        var create = await org.PostAsJsonAsync("/api/events", TestHelpers.EventBody(DateTime.UtcNow.AddDays(20)));
        Assert.Equal(HttpStatusCode.Created, create.StatusCode);
        var id = (await create.Content.ReadFromJsonAsync<System.Text.Json.JsonElement>()).GetProperty("id").GetInt32();

        var update = await org.PutAsJsonAsync($"/api/events/{id}",
            TestHelpers.EventBody(DateTime.UtcNow.AddDays(25), "Renamed Run"));
        Assert.Equal(HttpStatusCode.OK, update.StatusCode);

        var delete = await org.DeleteAsync($"/api/events/{id}");
        Assert.Equal(HttpStatusCode.NoContent, delete.StatusCode);

        var gone = await org.GetAsync($"/api/events/{id}");
        Assert.Equal(HttpStatusCode.NotFound, gone.StatusCode);
    }

    [Fact]
    public async Task Organiser_CreateEvent_InvalidData_Returns400()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var res = await org.PostAsJsonAsync("/api/events", new
        {
            name = "", description = "x", date = DateTime.UtcNow.AddDays(5),
            location = "Durban", distanceKm = 10, eventType = "Run"
        });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotUpdateAnotherOrganisersEvent_Returns403()
    {
        var (orgA, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (orgB, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var id = await TestHelpers.CreateEventAsync(orgA);

        var res = await orgB.PutAsJsonAsync($"/api/events/{id}", TestHelpers.EventBody(DateTime.UtcNow.AddDays(40)));
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotCreateEvent_Returns403()
    {
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var res = await participant.PostAsJsonAsync("/api/events", TestHelpers.EventBody(DateTime.UtcNow.AddDays(10)));
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task Participant_CanViewEvents_Returns200()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        await TestHelpers.CreateEventAsync(org);
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var res = await participant.GetAsync("/api/events");
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotUseParticipantEndpoint_Returns403()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var res = await org.GetAsync("/api/enrolments/mine");
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }
}
