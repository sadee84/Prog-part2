// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         AuthTests.cs
// Purpose:      Unit/integration tests: registration, login, session, logout.
// Attribution:  xUnit.net (n.d.) 'Getting started with xUnit.net'; Microsoft (n.d.) 'Integration tests in ASP.NET Core'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.Tests;

/// <summary>Registration, login, session and logout - success and failure cases.</summary>
public class AuthTests : IClassFixture<RaceDayApiFactory>
{
    private readonly RaceDayApiFactory _factory;
    public AuthTests(RaceDayApiFactory factory) => _factory = factory;

    [Fact]
    public async Task Register_ValidParticipant_Returns201()
    {
        var client = _factory.CreateClient();
        var res = await client.PostAsJsonAsync("/api/auth/register", new
        {
            firstName = "Thandi", lastName = "Zulu", email = TestHelpers.UniqueEmail(),
            password = TestHelpers.Password, role = "Participant"
        });
        Assert.Equal(HttpStatusCode.Created, res.StatusCode);
    }

    [Fact]
    public async Task Register_DuplicateEmail_Returns409()
    {
        var client = _factory.CreateClient();
        var body = new
        {
            firstName = "A", lastName = "B", email = TestHelpers.UniqueEmail(),
            password = TestHelpers.Password, role = "Participant"
        };
        await client.PostAsJsonAsync("/api/auth/register", body);
        var second = await client.PostAsJsonAsync("/api/auth/register", body);
        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task Register_ShortPassword_Returns400()
    {
        var client = _factory.CreateClient();
        var res = await client.PostAsJsonAsync("/api/auth/register", new
        {
            firstName = "A", lastName = "B", email = TestHelpers.UniqueEmail(),
            password = "123", role = "Participant"
        });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }

    [Fact]
    public async Task Login_ValidCredentials_Returns200_AndSessionHoldsRole()
    {
        var (client, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");

        var session = await client.GetAsync("/api/auth/session");
        Assert.Equal(HttpStatusCode.OK, session.StatusCode);

        var body = await session.Content.ReadFromJsonAsync<JsonElement>();
        Assert.Equal("Organiser", body.GetProperty("role").GetString());
    }

    [Fact]
    public async Task Login_WrongPassword_Returns401()
    {
        var (_, email, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var fresh = _factory.CreateClient();

        var res = await fresh.PostAsJsonAsync("/api/auth/login", new { email, password = "WrongPassword!" });
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }

    [Fact]
    public async Task ProtectedEndpoint_WithoutLogin_Returns401()
    {
        var client = _factory.CreateClient();
        var res = await client.GetAsync("/api/events");
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }

    [Fact]
    public async Task Logout_ClearsSession_SoNextRequestIs401()
    {
        var (client, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var logout = await client.PostAsync("/api/auth/logout", null);
        Assert.Equal(HttpStatusCode.OK, logout.StatusCode);

        var after = await client.GetAsync("/api/auth/session");
        Assert.Equal(HttpStatusCode.Unauthorized, after.StatusCode);
    }
}
