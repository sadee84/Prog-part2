// =====================================================================
// RaceDay API | Part 2 | Task preparation
// Author:       Sade Mzila
// File:         EnrolmentTests.cs
// Purpose:      Tests: enrolment rules and result capturing.
// Attribution:  xUnit.net (n.d.) 'Getting started with xUnit.net'.
// AI declaration: Claude (Anthropic, 2026) was used to understand the brief,
//                 structure the solution, generate the first draft of this
//                 code and help debug it. It was then reviewed and run by
//                 Sade Mzila. See the README for the full disclosure.
// =====================================================================
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.Tests;

/// <summary>Participants enrolling, organisers viewing enrolments, and capturing results.</summary>
public class EnrolmentTests : IClassFixture<RaceDayApiFactory>
{
    private readonly RaceDayApiFactory _factory;
    public EnrolmentTests(RaceDayApiFactory factory) => _factory = factory;

    [Fact]
    public async Task Participant_CanEnrol_AndEnrolmentIsRecorded()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var eventId = await TestHelpers.CreateEventAsync(org);
        var categoryId = await TestHelpers.CreateCategoryAsync(org, eventId);
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var res = await participant.PostAsJsonAsync($"/api/events/{eventId}/enrolments", new { categoryId });
        Assert.Equal(HttpStatusCode.Created, res.StatusCode);

        var mine = await participant.GetFromJsonAsync<JsonElement>("/api/enrolments/mine");
        Assert.Equal(1, mine.GetArrayLength());
        Assert.Equal("Confirmed", mine[0].GetProperty("status").GetString());
    }

    [Fact]
    public async Task Participant_EnrolTwice_Returns409()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var eventId = await TestHelpers.CreateEventAsync(org);
        var categoryId = await TestHelpers.CreateCategoryAsync(org, eventId);
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");

        await TestHelpers.EnrolAsync(participant, eventId, categoryId);
        var second = await participant.PostAsJsonAsync($"/api/events/{eventId}/enrolments", new { categoryId });
        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task Participant_EnrolWithCategoryFromAnotherEvent_Returns400()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var eventA = await TestHelpers.CreateEventAsync(org);
        var eventB = await TestHelpers.CreateEventAsync(org);
        var categoryOfB = await TestHelpers.CreateCategoryAsync(org, eventB);
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var res = await participant.PostAsJsonAsync($"/api/events/{eventA}/enrolments", new { categoryId = categoryOfB });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotEnrol_Returns403()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var eventId = await TestHelpers.CreateEventAsync(org);
        var categoryId = await TestHelpers.CreateCategoryAsync(org, eventId);

        var res = await org.PostAsJsonAsync($"/api/events/{eventId}/enrolments", new { categoryId });
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanViewEnrolmentsForOwnEvent_Returns200()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var eventId = await TestHelpers.CreateEventAsync(org);
        var categoryId = await TestHelpers.CreateCategoryAsync(org, eventId);
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");
        await TestHelpers.EnrolAsync(participant, eventId, categoryId);

        var list = await org.GetFromJsonAsync<JsonElement>($"/api/events/{eventId}/enrolments");
        Assert.Equal(1, list.GetArrayLength());
    }

    [Fact]
    public async Task Participant_CannotViewEventEnrolments_Returns403()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var eventId = await TestHelpers.CreateEventAsync(org);
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var res = await participant.GetAsync($"/api/events/{eventId}/enrolments");
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task Organiser_CapturesResult_AfterEvent_ParticipantCanSeeIt()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var eventId = await TestHelpers.CreateEventAsync(org);
        var categoryId = await TestHelpers.CreateCategoryAsync(org, eventId);
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var enrolmentId = await TestHelpers.EnrolAsync(participant, eventId, categoryId);

        // Move the event into the past (the race has now been run)
        var moved = await org.PutAsJsonAsync($"/api/events/{eventId}",
            TestHelpers.EventBody(DateTime.UtcNow.AddDays(-1)));
        Assert.Equal(HttpStatusCode.OK, moved.StatusCode);

        var capture = await org.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/result",
            new { finishTime = "00:52:10", finishingPosition = 1 });
        Assert.Equal(HttpStatusCode.Created, capture.StatusCode);

        var mine = await participant.GetFromJsonAsync<JsonElement>("/api/results/mine");
        Assert.Equal(1, mine.GetArrayLength());
        Assert.Equal(1, mine[0].GetProperty("finishingPosition").GetInt32());
    }

    [Fact]
    public async Task Organiser_CaptureResult_BeforeEvent_Returns400()
    {
        var (org, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var eventId = await TestHelpers.CreateEventAsync(org);
        var categoryId = await TestHelpers.CreateCategoryAsync(org, eventId);
        var (participant, _, _) = await TestHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var enrolmentId = await TestHelpers.EnrolAsync(participant, eventId, categoryId);

        var res = await org.PostAsJsonAsync($"/api/enrolments/{enrolmentId}/result",
            new { finishTime = "00:50:00", finishingPosition = 1 });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }
}
